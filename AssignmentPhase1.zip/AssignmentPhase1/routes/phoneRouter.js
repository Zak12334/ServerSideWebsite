const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const phones = require('../models/phone');

const phoneRouter = express.Router();

phoneRouter.route('/')
.get((req,res,next) => {
})
.post((req, res, next) => {
})
.put((req, res, next) => {
})
.delete((req, res, next) => {
});


phoneRouter.route('/create') // creates a path

.get((req,res,next) => {
    res.render('newusage.ejs', { title: 'Daily Activity' });   
})

.post((req, res, next) => {
    phones.create(req.body)
    .then((phonecreated) => {
        phones.find()
         .then((phonesfound) => {
                res.render('currentusage',{'phonelist' : phonesfound, title:''} );
        }, (err) => next(err))
    .catch((err) => next(err));
    }, (err) => next(err))
    .catch((err) => next(err));
})

.put((req, res, next) => {
    res.statusCode = 403;
    res.end('PUT operation not supported on /phones/create');
})

.delete((req, res, next) => {
    res.statusCode = 403;
    res.end('Delete operation not  supported on /phones/create');
    
});


module.exports = phoneRouter;