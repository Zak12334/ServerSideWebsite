const mongoose = require('mongoose');
const Schema = mongoose.Schema;

require('mongoose-currency').loadType(mongoose);
var Currency = mongoose.Types.Currency;


var phoneSchemaful = new Schema({
    name: {
        type: String,
        required: true,
    },
    app: {
        type: String,
        required: true
    },
    hours: {
        type: String,
        required: true
    },
    date: {
        type: String,
        required: true
    }
}, {
    timestamps: true
});
var phones = mongoose.model('phone', phoneSchemaful);

module.exports = phones;